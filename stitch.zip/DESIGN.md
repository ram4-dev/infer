# Design System Strategy: The Technical Authority

## 1. Overview & Creative North Star
**Creative North Star: "The Sovereign Console"**
This design system moves away from the "consumerized" SaaS aesthetic to embrace a raw, high-performance technical soul. We are building for engineers who live in the terminal. The goal is to create an interface that feels like a precision instrument: silent, fast, and authoritative. 

We break the "standard" layout template by leaning into **intentional asymmetry**. Instead of centered, "friendly" landing pages, we use left-heavy technical alignments, monospace hierarchies, and a "dashboard-first" philosophy. The UI doesn't hold the user's hand; it provides the high-fidelity data and low-latency controls they need to execute.

---

## 2. Colors & Surface Logic
The palette is rooted in a "Deep Obsidian" foundation (`#131313`) punctuated by "Radioactive Neon" accents. We avoid generic gradients in favor of high-contrast, functional color application.

### The "No-Line" Rule
**Prohibit 1px solid borders for structural sectioning.** 
To achieve a premium, integrated feel, boundaries must be defined by background shifts. 
- A sidebar should be `surface_container_low` sitting against a `surface` main stage.
- Content groupings should use `surface_container_highest` to pull focus, not a stroke.
- Separation is achieved through **Tonal Stepping**, not drawing lines.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers of varying density:
- **Base Layer:** `surface` (#131313) — The bedrock.
- **Deeper Pockets:** `surface_container_lowest` (#0e0e0e) — Use for recessed code editors or "well" components.
- **Elevated Interactive Zones:** `surface_container_high` (#2a2a2a) — Use for cards and floating panels.

### The "Glass & Gradient" Rule
While we avoid "candy" gradients, we use **Functional Glows**. 
- Main CTAs should utilize a subtle transition from `primary` (#ebffe2) to `primary_container` (#00ff41). 
- For floating command palettes or technical overlays, use **Glassmorphism**: `surface_variant` at 60% opacity with a `20px` backdrop-blur. This ensures the technical data "underneath" remains visible, reinforcing the high-performance feel.

---

## 3. Typography: The Monospace Hierarchy
We use a high-contrast pairing: **Space Grotesk** (Monospace feel, display precision) for headers and **Inter** (Humanist clarity) for long-form data.

| Level | Token | Font | Size | Intent |
| :--- | :--- | :--- | :--- | :--- |
| **Display** | `display-lg` | Space Grotesk | 3.5rem | High-impact technical stats. |
| **Headline** | `headline-sm` | Space Grotesk | 1.5rem | Section headers; feels like a terminal prompt. |
| **Body** | `body-md` | Inter | 0.875rem | Documentation and descriptions. |
| **Label** | `label-sm` | Space Grotesk | 0.6875rem | Metadata, tags, and micro-copy. |

**The Signature Move:** All headers (`display` to `headline`) must be set in **Sentence case** or **lowercase** to mimic code environments. Never use All-Caps for technical headers; it feels too "marketing."

---

## 4. Elevation & Depth
Depth in this system is "Industrial," not "Organic." 

- **The Layering Principle:** Stack `surface-container` tiers. A `surface-container-low` card sitting on a `surface` background creates a natural lift.
- **Ambient Shadows:** Shadows are rare. When used for floating modals, use a 12% opacity shadow tinted with `surface_tint` (#00e639) rather than black. Blur: `40px`, Spread: `-10px`.
- **The "Ghost Border" Fallback:** If accessibility requires a border, use `outline_variant` (#3b4b37) at **15% opacity**. It should be felt, not seen.
- **Tactile Inputs:** Inputs should feel "carved" into the UI. Use `surface_container_lowest` for the field background to create a recessed, high-precision aesthetic.

---

## 5. Components

### Buttons (The "Actuators")
- **Primary:** Background: `primary` (#ebffe2); Text: `on_primary`. Corner radius: `sm` (0.125rem) for a sharp, technical look.
- **Secondary:** Ghost style. No background, `outline` border at 20% opacity. On hover, background becomes `surface_container_high`.
- **Tertiary/Terminal:** Entirely monospace (`label-md`). Prepended with a `>` character (e.g., `> RUN_INFERENCE`).

### Technical Form Inputs
- **Fields:** Recessed background (`surface_container_lowest`). Focus state: A 1px `secondary` (#46eaed) glow on the bottom edge only.
- **Syntax Highlighting:** Use `secondary` for strings, `primary_fixed` for functions, and `tertiary_fixed` for variables within code blocks.

### Cards & Lists (The "Data Grid")
- **Forbid Divider Lines.** Separate list items using `12px` of vertical white space or a subtle hover shift to `surface_container_low`. 
- **The "Model Card":** Use a `surface_container_high` background. In the top right, place a `label-sm` monospace tag indicating "LATENCY: 12ms" in `primary`.

### Specialized: The Inference Pulse
- **Status Indicator:** Instead of a static dot, use a `2px` wide vertical bar that subtly pulses between `primary` and `primary_container`. This signals "Active" or "Processing" in a way that feels unique to an AI marketplace.

---

## 6. Do's and Don'ts

### Do
- **Use Monospace for Numbers:** Always use Space Grotesk for any numerical data (latency, price, tokens).
- **Embrace Asymmetry:** Align technical specs to the right and descriptions to the left to break the "webpage" feel.
- **Use "Terminal Green" Sparingly:** Use `primary_fixed` only for success states or primary actions. Overuse kills the "high-end" feel.

### Don't
- **No Soft Corners:** Never use `xl` (0.75rem) or `full` rounding for primary UI. Keep everything to `sm` or `md` to maintain the "instrument" aesthetic.
- **No Large Gradients:** Avoid any background that uses more than a 5% shift in hue. We want deep, matte surfaces.
- **No Icons without Labels:** This is a professional tool. If an icon is used, a monospace label (`label-sm`) should accompany it to ensure zero ambiguity.